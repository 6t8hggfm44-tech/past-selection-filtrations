# P1 maintenance note — 2026-10-19 (staged; not yet committed)

Append after the 2026-10-12 rotating-axis discussion in `open-problems/QUEUE.md`:

**2026-10-19 partial quantitative rescue:** For pure conditional branches in an explicitly declared closed finite-dimensional model, define B_I(t)=U0† B(t)U0, δ(t)=sqrt(Var_ψ0(B_I(t))) and J(t)=∫δ. The standard Fubini–Study path-length bound yields arccos V(t)≤J(t), hence V≥cos J and Sigma≤−log cos J for J<π/2. Deterministic simultaneous operator-norm calibration tubes on H0,B propagate conservatively into a common upper bound J_star. This quantifies approximate null quality when exact alignment fails; it is *not* a complete device-level target certificate. Continue including all calibrated joint/contextual/memory/leakage/spectator ordinary models and freeze the full held-out target set before shot optimization.

Do not mark P1 complete.
