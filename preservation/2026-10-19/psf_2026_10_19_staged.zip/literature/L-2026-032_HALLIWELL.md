### L-2026-032 — Halliwell, “Somewhere in the Universe: Where Is the Information Stored When Histories Decohere?” (1999)

- **Date assessed:** 2026-10-19.
- **Source access:** publisher abstract plus preprint abstract assessed; full theorem-by-theorem manuscript not audited in this pass.
- **Relevance:** direct **historical, pre-2025 conceptual prior art** for information about earlier histories residing in environmental records; N1/P2.
- **What overlaps:** Discusses the connection between decoherent histories and environmental information storage, including imperfect records for mixed initial states and records of temporally nonlocal Fourier components of a trajectory encoded in oscillator observables at a later time. Thus past records and imperfect access are not new concepts in isolation.
- **What differs/uncertain:** Abstract evidence does not establish equivalence to the full PSF increasing von Neumann record filtration, compatible branch-record states, expected-lift identity, root-fidelity visibility envelope or specific quantitative bounds. Do not infer theorem overlap from wording alone.
- **Novelty threat:** strong against any unqualified claim that PSF first recognized quantum environmental records of past histories; unassessed for PSF's narrower theorem-specific mathematical synthesis.
- **Useful contribution:** Candidate historical citation; read full paper and its descendants before making an originality claim about observer-accessible past states.
- **Sources:** https://doi.org/10.1103/PhysRevD.60.105031 ; https://arxiv.org/abs/quant-ph/9902008 .
